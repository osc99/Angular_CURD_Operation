export class Employee {
    _id: string='';
    fullName: string='';
    position: string='';
    location: string='';
    salary: string='';
}
